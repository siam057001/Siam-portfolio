// Theme (remembered between visits)
const root = document.documentElement;
try { const t = localStorage.getItem('theme'); if (t) root.dataset.theme = t; } catch (e) {}
document.getElementById('theme').onclick = () => {
  const next = root.dataset.theme === 'light' ? 'dark' : 'light';
  root.dataset.theme = next;
  try { localStorage.setItem('theme', next); } catch (e) {}
};

// Mobile menu
const menu = document.getElementById('menu');
document.getElementById('burger').onclick = () => menu.classList.toggle('open');
menu.querySelectorAll('a').forEach(a => a.onclick = () => menu.classList.remove('open'));

// Typing effect – edit these roles
const roles = ['Web Developer', 'Software Engineering Student', 'Problem Solver', 'Lifelong Learner'];
const typed = document.getElementById('typed');
let r = 0, c = 0, del = false;
(function type() {
  const word = roles[r];
  typed.textContent = word.slice(0, c);
  if (!del && c === word.length) { del = true; return setTimeout(type, 1400); }
  if (del && c === 0) { del = false; r = (r + 1) % roles.length; }
  c += del ? -1 : 1;
  setTimeout(type, del ? 50 : 100);
})();

// Reveal on scroll + animate skill bars and counters
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    e.target.classList.add('show');
    e.target.querySelectorAll('.bar i').forEach(i => i.style.width = i.dataset.w + '%');
    e.target.querySelectorAll('[data-count]').forEach(el => {
      const end = +el.dataset.count; let n = 0;
      const id = setInterval(() => { n++; el.textContent = n + '+'; if (n >= end) clearInterval(id); }, 90);
    });
    io.unobserve(e.target);
  });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// Contact form -> opens the visitor's email app (works on any static host)
document.getElementById('form').addEventListener('submit', ev => {
  ev.preventDefault();
  const f = new FormData(ev.target);
  const body = `${f.get('msg')}\n\n— ${f.get('name')} (${f.get('email')})`;
  location.href = `mailto:251-35-337@diu.edu.bd?subject=${encodeURIComponent('Portfolio message from ' + f.get('name'))}&body=${encodeURIComponent(body)}`;
  document.getElementById('note').textContent = 'Opening your email app…';
});

document.getElementById('year').textContent = new Date().getFullYear();
